document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("cadastro-form");
    const tabela = document.querySelector("#tabela-participantes tbody");
    const contador = document.getElementById("contador");
    const comentarios = document.getElementById("comentarios");
    const toggleThemeBtn = document.getElementById("toggle-theme");

    function validarFormulario() {
        let valido = true;

        const nome = form.nome.value.trim();
        const email = form.email.value.trim();
        const data = form["data-nascimento"].value;
        const genero = form.genero.value;
        const interesses = [...form.querySelectorAll("input[name='interesses']:checked")];
        const area = form.area.value;

        document.querySelectorAll(".erro").forEach(el => el.textContent = "");

        if (!nome) {
            document.getElementById("erro-nome").textContent = "Nome é obrigatório.";
            valido = false;
        }
        if (!email) {
            document.getElementById("erro-email").textContent = "E-mail é obrigatório.";
            valido = false;
        }
        if (!data) {
            document.getElementById("erro-data").textContent = "Data de nascimento é obrigatória.";
            valido = false;
        }
        if (!genero) {
            document.getElementById("erro-genero").textContent = "Selecione um gênero.";
            valido = false;
        }
        if (interesses.length === 0) {
            document.getElementById("erro-interesses").textContent = "Selecione pelo menos um interesse.";
            valido = false;
        }
        if (!area) {
            document.getElementById("erro-area").textContent = "Selecione uma área.";
            valido = false;
        }

        return valido;
    }

    function salvarParticipante(data) {
        let participantes = JSON.parse(localStorage.getItem("participantes") || "[]");
        participantes.push(data);
        localStorage.setItem("participantes", JSON.stringify(participantes));
    }

    function carregarParticipantes() {
        let participantes = JSON.parse(localStorage.getItem("participantes") || "[]");
        participantes.forEach(p => adicionarNaTabela(p));
    }

    function adicionarNaTabela(participante) {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${participante.nome}</td>
            <td>${participante.email}</td>
            <td>${participante.data}</td>
            <td>${participante.genero}</td>
            <td>${participante.interesses.join(", ")}</td>
            <td>${participante.area}</td>
        `;
        tabela.appendChild(row);
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        if (validarFormulario()) {
            const participante = {
                nome: form.nome.value.trim(),
                email: form.email.value.trim(),
                data: form["data-nascimento"].value,
                genero: form.genero.value,
                interesses: [...form.querySelectorAll("input[name='interesses']:checked")].map(i => i.value),
                area: form.area.value
            };
            salvarParticipante(participante);
            adicionarNaTabela(participante);
            form.reset();
            contador.textContent = "0/200";
        }
    });

    comentarios.addEventListener("input", function () {
        contador.textContent = `${comentarios.value.length}/200`;
    });

    toggleThemeBtn.addEventListener("click", function () {
        document.body.classList.toggle("dark-theme");
    });

    carregarParticipantes();
});